package KhanbanTasks;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class KhanbanTask {

    public static Account account = new Account();
    public static List<Task> taskList = new ArrayList<Task>();

    public static void main(String[] args) {

//        allow the user to capture the firstname
        String firstName = JOptionPane.showInputDialog("Please Enter First Name");
        account.firstName = firstName;
// allow user to capture surname
        String surname = JOptionPane.showInputDialog("Please enter surname");
        account.lastName = surname;
//Register User
        String message = registerUser();
        JOptionPane.showMessageDialog(null, account.username + message);
        boolean isLoggedIn = false;
        while (!isLoggedIn) {
            isLoggedIn = loginUser();
            JOptionPane.showMessageDialog(null, returnLoginStatus(isLoggedIn));
        }
        Task task = new Task();
        Object[] possibleValues = {"1) Add Tasks", "2) Show Report",
            "3) Quit"};
        Object selectedValue = null;
        while (selectedValue != "3) Quit") {
            selectedValue = JOptionPane.showInputDialog(null,
                    "Choose one", "Input", JOptionPane.INFORMATION_MESSAGE, null,
                    possibleValues, possibleValues[0]);

            int totalTasks = 0;

            switch (selectedValue.toString()) {
                case "1) Add Tasks":
                    int totalDuration = 0;
                    String numberOfTasks = JOptionPane.showInputDialog("How many tasks would you like to add?");
                    System.out.println("tasks to be added : " + numberOfTasks);

                    while (totalTasks < Integer.parseInt(numberOfTasks)) {
                        totalTasks++;
                        String taskName = JOptionPane.showInputDialog("Please enter task name");
                        task.setTaskName(taskName);
                        task.setTaskNumber(totalTasks);
                        boolean validDescr = false;
                        while (!validDescr) {
                            validDescr = task.checkTaskDescription();
                        }
                        JOptionPane.showMessageDialog(null, "Task Successfully Captured");
                        String devDetails = JOptionPane.showInputDialog("Please enter Developer Details");
                        task.setDeveloperDetails(devDetails);
                        String taskDuration = JOptionPane.showInputDialog("Please enter task duration");
                        task.setTaskDuration(Integer.parseInt(taskDuration));
                        totalDuration = totalDuration + task.getTaskDuration();
                        task.setTaskId(task.createTaskID());
                        Object[] values = {"To Do", "Done", "Doing"};
                        Object valueSelected = JOptionPane.showInputDialog(null,
                                "Choose one", "Input", JOptionPane.INFORMATION_MESSAGE, null,
                                values, values[0]);
                        task.setTaskStatus((String) valueSelected);
                        JOptionPane.showMessageDialog(null, "Task Details: " + task.printTaskDetails());
                        taskList.add(task);
                        task = new Task();
                    }
                    JOptionPane.showMessageDialog(null, "Total Duartion Of Tasks: " + task.returnTotalHours(taskList));
                    break;
                case "2) Show Report":
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
            }
        }

    }

    public static boolean checkUserName(String username) {
//
        if (!username.contains("_")) {
            return false;
//        
        } else if (username.length() > 5) {
            return false;
        }

        return true;
    }

    public static boolean checkPasswordComplexity(String password) {
//    check if password is at least 8 chars
        if (password.length() < 8) {
            return false;
        }
//       check that password contains a special character
        Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(password);
        boolean hasSpecialChar = m.find();
        if (!hasSpecialChar) {
            return false;
        }
//        check that password contains a number
        p = Pattern.compile("[0-9]");
        m = p.matcher(password);
        boolean containsNumber = m.find();
        if (!containsNumber) {
            return false;
        }

//        check that password contains 1 Capital letter
        p = Pattern.compile("[A-Z]");
        m = p.matcher(password);
        boolean containsCapitals = m.find();
        return containsCapitals;
    }

    public static String registerUser() {
        //Allow user to capture username
        String userName = JOptionPane.showInputDialog("Please enter username");
        account.username = userName;
        boolean isValidUserName = false;
        //validate username
        while (!isValidUserName) {
            isValidUserName = checkUserName(userName);
            if (!isValidUserName) {
                JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
                userName = JOptionPane.showInputDialog("Please enter username");
                account.username = userName;
            }
        }

        //allow user to capture password
        String password = JOptionPane.showInputDialog("Please enter password");
        account.password = password;
        boolean isValidPassword = false;
        //  validate password
        while (!isValidPassword) {
            isValidPassword = checkPasswordComplexity(password);
            if (!isValidPassword) {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
                password = JOptionPane.showInputDialog("Please enter password");
                account.password = password;
            }
        }

        return " has been registered successfully";
    }

    public static boolean loginUser() {
        //Allow User to login
        String username = JOptionPane.showInputDialog("Please enter username to login");
        String password = JOptionPane.showInputDialog("Please enter password to login");
        boolean usernameCorrect = false;
        boolean passwordCorrect = false;
        if (username.equalsIgnoreCase(account.getUsername())) {
            usernameCorrect = true;
        }
        if (password.equals(account.getPassword())) {
            passwordCorrect = true;
        }
        return usernameCorrect && passwordCorrect;
    }

    public static String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return ("Welcome to EasyKanban");
        } else {
            return ("Username or password incorrect, please try again");
        }
    }

}
